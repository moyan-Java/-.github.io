# demo blog

Open terminal and run:

```bash
git clone https://github.com/volantis-x/demo.git && cd demo && npm i && hexo s
```
