title: Images
date: 2013-12-26 22:46:49
---

This is a image test post.

![](https://cdn.jsdelivr.net/gh/hexojs/hexo-theme-unit-test@master/source/assets/wallpaper-2572384.jpg)

![Caption](https://cdn.jsdelivr.net/gh/hexojs/hexo-theme-unit-test@master/source/assets/wallpaper-2311325.jpg)

![](https://cdn.jsdelivr.net/gh/hexojs/hexo-theme-unit-test@master/source/assets/wallpaper-878514.jpg)

![Small Picture](https://placehold.it/350x150.jpg)
